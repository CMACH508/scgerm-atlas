<?php

namespace app\index\controller;
header("Content-type: application/json");
header('Access-Control-Allow-Origin:*');
header("Access-Control-Allow-Methods: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Access-Token,Content-Length, Accept-Encoding, X-Requested-With, Origin");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Expose-Headers: *");
header('Access-Control-Allow-Methods: GET, POST, PUT,DELETE,OPTIONS,PATCH');

use think\Paginator;

use think\facade\Request;
use think\facade\Db;
use app\BaseController;
use PHPExcel;
use PHPExcel_IOFactory;

class Api extends BaseController
{
    public function upload()
    {
        //http://originsoftware.cn/xinxifabu/public/index/index/upload         //上传接口
        //传一个'file'类型的参数，参数名为"image"
        $up = new \fileupload;
        $project_id = input('project_id');
        $file_name = input('file_name');

        if ($file_name || is_array($_FILES['image']['name'])) {
            $up->set("israndname", false);
            if ($file_name) {
                $up->set('newFileName', $file_name);
            } else {
                $up->set("israndname", 2);
            }
            if (is_array($_FILES['image']['name'])) {
                $up->set("israndname", 0);
            }
        } else {
            $up->set("israndname", true);
        }


        $project_id = isset($project_id) ? $project_id : 'uploads';
        $up->set("path", "./../public/" . $project_id . "/");
        $up->set("maxsize", 4000000000); //上传大小限制4000M
        $up->set("allowtype", array("png", "jpg", "JPG", "jpeg", "doc", "docx", "pdf", "mp4", "ppt", "pptx", "otf", "ttf"));//上传文件类型限制
        $file = $up->upload("image");
        $request = Request::instance();
        $err = $up->getErrorMsg();
        // var_dump($_FILES);exit;
        if ($file) {
            $name = $up->getFileName();
            if (is_array($name)) {
                $true_name = $_FILES['image']['name'];
                $url = $request->url();
                $floor = $this->cut_str($url, 'public', 0);
                $url = [];
                $complete_url = [];
                foreach ($name as $value) {
                    $url[] = 'public/' . $project_id . '/' . $value;
                    $complete_url[] = $request->domain() . $floor . 'public/' . $project_id . '/' . $value;
                }
            } else {
                $true_name = $_FILES['image']['name'];
                $url = $request->url();
                $floor = $this->cut_str($url, 'public', 0);
                $url = 'public/' . $project_id . '/' . $name;
                $complete_url = $request->domain() . $floor . 'public/' . $project_id . '/' . $name;
            }

        } else {
            $insert_result = array('result' => "false", 'error' => "-1", 'msg' => $err);
            $json = json_encode($insert_result);
            echo $json;
            exit();
        }
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => "/" . $url, 'complete_url' => $complete_url, 'file_name' => $true_name);
        $json = json_encode($insert_result);
        echo $json;
        exit();
    }

    public function uploadForImport()
    {
        $up = new \fileupload;
        $up->set("israndname", false);
        $up->set("israndname", 0);
        $up->set("path", "./../public/uploads/");
        $up->set("maxsize", 40000000); //上传大小限制40M
        $up->set("allowtype", array("png", "jpg", "JPG", "jpeg"));//上传文件类型限制
        $file = $up->upload("image");
        $err = $up->getErrorMsg();
        if ($file) {
            $name = $up->getFileName();

            $result = [];
            if (!is_array($_FILES['image']['name'])) {
                //单张
                $result_arr =  explode("-", explode(".", $name)[0]);
                if (count($result_arr) >= 4) {
                    $result['education_background'] = $result_arr[0];
                    $result['year'] = $result_arr[1];
                    $result['profession'] = $result_arr[2];
                    $result['class'] = $result_arr[3];
                    $result['name'] = $name;
                    $result['img_url'] = "/public/uploads/" . $name;
                    Db::name('picInfo')->insert($result);
                }
            } else {
                $n = 0;
                //多张
                foreach ($name as $key => $value) {
                    $result_arr =  explode("-", explode(".", $value)[0]);
                    if (count($result_arr) >= 4) {
                        $result[$n]['education_background'] = $result_arr[0];
                        $result[$n]['year'] = $result_arr[1];
                        $result[$n]['profession'] = $result_arr[2];
                        $result[$n]['class'] = $result_arr[3];
                        $result[$n]['name'] = $value;
                        $result[$n]['img_url'] = "/public/uploads/" . $value;
                        $n++;
                    }
                }
                Db::name('picInfo')->insertAll($result);
            }

        } else {
            $insert_result = array('result' => "false", 'error' => "-1", 'msg' => $err);
            $json = json_encode($insert_result);
            echo $json;
            exit();
        }

        $insert_result = array('result' => "success", 'error' => "0", 'msg' => "导入成功！", "data" => "0");
        $json = json_encode($insert_result);
        echo $json;
        exit();
    }


    //POST方式提交参数
    public function api_notice_increment($url, $qrcode)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
//        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $qrcode);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            curl_close($ch);
            return $ch;
        } else {
            curl_close($ch);
            return $tmpInfo;
        }
    }

    //GET方式提交参数
    function api_notice_get($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            curl_close($ch);
            return $ch;
        } else {
            curl_close($ch);
            return $tmpInfo;
        }
    }

    public function importExcel($filePath)
    {

        // 加载excel文件
        $excel = PHPExcel_IOFactory::load($filePath);

        // 获取第一个工作表
        $sheet = $excel->getSheet(0);

        // 获取行数和列数
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();
        // 读取数据
        $data = [];
        for ($row = 2; $row <= $highestRow; $row++) {
            for ($col = 'A'; $col <= $highestColumn; $col++) {
                $data[$row][$col] = $sheet->getCell($col . $row)->getFormattedValue();
            }
        }

//        echo json_encode($data);exit;
        // 处理数据
        // ...

        return $data;
    }

    public function cut_str($str, $sign, $number)
    {
        $array = explode($sign, $str);
        $length = count($array);
        if ($number < 0) {
            $new_array = array_reverse($array);
            $abs_number = abs($number);
            if ($abs_number > $length) {
                return 'error';
            } else {
                return $new_array[$abs_number - 1];
            }
        } else {
            if ($number >= $length) {
                return 'error';
            } else {
                return $array[$number];
            }
        }
    }


    public function getRandStr($length)
    {
        //获取随机字符串
        $rand = date("ymd");
        $d = '';
        for ($n = 0; $n < $length; $n++) {
            $a = rand(1, 2);
            if ($a == 1) {
                $b = rand(0, 9);
            } else {
                $b = rand(0, 25);
                $c = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
                $b = $c[$b];
            }
            $d = $d . $b;
        }
        return $rand = $rand . $d;
    }



}
