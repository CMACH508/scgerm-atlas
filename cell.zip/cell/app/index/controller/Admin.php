<?php

namespace app\index\controller;

header("Content-type: application/json");
header('Access-Control-Allow-Origin:*');
header("Access-Control-Allow-Methods: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Access-Token,Content-Length, Accept-Encoding, X-Requested-With, Origin,token,Authorization");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Expose-Headers: *");
header('Access-Control-Allow-Methods: GET, POST, PUT,DELETE,OPTIONS,PATCH');

use app\BaseController;
use think\facade\Db;
use think\Request;
use think\facade\View;

class Admin extends BaseController
{
    public function initialize()
    {

        header("Content-type: application/json");
        header('Access-Control-Allow-Origin:*');
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Credentials: true");
        header("Access-Control-Allow-Headers: Content-Type, Access-Token,Content-Length, Accept-Encoding, X-Requested-With, Origin,token,Authorization");
        header("Access-Control-Allow-Headers: *");
        header("Access-Control-Expose-Headers: *");
        header('Access-Control-Allow-Methods: GET, POST, PUT,DELETE,OPTIONS,PATCH');

        parent::initialize();
        if (request()->isOptions()) {
            header("Access-Control-Allow-Origin: *");
            header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization,token");
            header('Access-Control-Allow-Methods: GET, POST');
            exit;
        }
    }

    public function index()
    {
        return '<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} a{color:#2E5CD5;cursor: pointer;text-decoration: none} a:hover{text-decoration:underline; } body{ background: #fff; font-family: "Century Gothic","Microsoft yahei"; color: #333;font-size:18px;} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.6em; font-size: 42px }</style><div style="padding: 24px 48px;"> <h1>:) </h1><p> ThinkPHP V' . \think\facade\App::version() . '<br/><span style="font-size:30px;">16载初心不改 - 你值得信赖的PHP框架</span></p><span style="font-size:25px;">[ V6.0 版本由 <a href="https://www.yisu.com/" target="yisu">亿速云</a> 独家赞助发布 ]</span></div><script type="text/javascript" src="https://e.topthink.com/Public/static/client.js"></script><think id="ee9b1aa918103c4fc"></think>';
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }

    public function login2()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $account = input('username');
            $password = input('password');
            $exist_count = Db::name('login')->where(['account' => $account, 'password' => $password])->count();
            if ($exist_count) {
                $insert_result = array('result' => "success", 'error' => "0", 'msg' => '登录成功', 'data' => "0");
            } else {
                $insert_result = array('result' => "false", 'error' => "-1", 'msg' => '登录失败，账号或密码错误', 'data' => "0");
            }
        } else {
            $insert_result = array('result' => "false", 'error' => "-1", 'msg' => '登录失败，请联系管理员', 'data' => "0");
        }
        $json = json_encode($insert_result);
        echo $json;
    }

    public function updatePassword()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $password = input('password');
            Db::name('login')->where('id', 1)->update(['password' => $password]);
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '修改成功', 'data' => "0");
            $json = json_encode($insert_result);
            echo $json;
        }
    }

    public function saveLifeDiscoveryInfo()
    {
        $data = [
            "age" => input("age"),//年龄
            "year" => input("year"),//年份
            "content" => input("content"),//生平大事记
            "year_story" => input("year_story"),//年谱精选
            "life_choiceness_pic" => input("life_choiceness_pic"),//生平精选图片
            "story_content" => input("story_content"),//宋庆龄与中国共产党史事节选
            "year_story_content" => input("year_story_content"),//宋庆龄与中国共产党史事编年精选
            "choiceness_pic" => input("choiceness_pic")//精选图片
        ];
        $exist = Db::name('lifeDiscovery')->where(['year' => $data['year'], 'content' => $data['content']])->count();
        if ($exist) {
            $insert_result = array('result' => "false", 'error' => "-1", 'msg' => "保存失败，信息已存在", 'data' => []);
        } else {
            Db::name('lifeDiscovery')->insert($data);
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => "保存成功", 'data' => []);
        }
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getLifeDiscoveryInfo()
    {
        $year = input('year');
        $content = input('content');
        $life_choiceness_pic = input('life_choiceness_pic');
        $choiceness_pic = input('choiceness_pic');
        $page = input('page');
        $count = input('count');
        $order_status = input('order_status');
        $p = ($page - 1) * $count;
        $where = [];
        if ($year) {
            $where['year'] = $year;
        }
        if ($content) {
            $where[] = ['content', 'like', '%' . $content . '%'];
        }
        if (strlen($life_choiceness_pic)) {
            if ($life_choiceness_pic) {//字段不为空的情况
                //'LENGTH(your_field_name) > 0'
                $where[] = ['life_choiceness_pic', "<>", ""];
            } else {//字段为空的情况
                $where[] = ['life_choiceness_pic', "=", ""];
            }
        }
        if (strlen($choiceness_pic)) {
            if ($choiceness_pic) {//字段不为空的情况
                $where[] = ['choiceness_pic', "<>", ""];
            } else {//字段为空的情况
                $where[] = ['choiceness_pic', "=", ""];
            }
        }

        if ($order_status) {
            $order_arr = ["year" => $order_status];
        }else{
            $order_arr = ["id" => "desc"];
        }
        $res = Db::name('lifeDiscovery')->where($where)->order($order_arr)->limit($p, $count)->select();
        $total = Db::name('lifeDiscovery')->where($where)->count();
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $res, "total" => $total]);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function updateLifeDiscoveryInfo()
    {
        $id = input('id');
        $data = [
            "age" => input("age"),//年龄
            "year" => input("year"),//年份
            "content" => input("content"),//生平大事记
            "year_story" => input("year_story"),//年谱精选
            "life_choiceness_pic" => input("life_choiceness_pic"),//生平精选图片
            "story_content" => input("story_content"),//宋庆龄与中国共产党史事节选
            "year_story_content" => input("year_story_content"),//宋庆龄与中国共产党史事编年精选
            "choiceness_pic" => input("choiceness_pic")//精选图片
        ];
        Db::name('lifeDiscovery')->where('id', $id)->update($data);
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '修改成功', 'data' => "0");

        $json = json_encode($insert_result);
        echo $json;
    }

    public function DeleteLifeDiscoveryInfo()
    {
        $id = input('id');
        Db::name('lifeDiscovery')->where('id', $id)->delete();
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '删除成功', 'data' => "0");
        $json = json_encode($insert_result);
        echo $json;
    }

    public function saveRelationInfo()
    {
        $data = [
            "module" => input("module"),//模块
            "name" => input("name"),//姓名
            "color" => input("color"),//颜色
            "level" => input("level"),//重要级别
            "introduction" => input("introduction"),//人物简介
            "person_img" => input("person_img"),//人物图片
            "intersection_incident" => input("intersection_incident"),//和宋庆龄的交集事件
            "group_photo" => input("group_photo")//人物与宋庆龄合照
        ];
        $exist = Db::name('relationInfo')->where(['name' => $data['name']])->count();
        if ($exist) {
            $insert_result = array('result' => "false", 'error' => "-1", 'msg' => "保存失败，信息已存在", 'data' => []);
        } else {
            Db::name('relationInfo')->insert($data);
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => "保存成功", 'data' => []);
        }
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getRelationInfo()
    {
        $name = input('name');
        $color = input('color');
        $level = input('level');
        $introduction = input('introduction');
        $person_img = input('person_img');
        $intersection_incident = input('intersection_incident');
        $page = input('page');
        $count = input('count');
        $order_status = input('order_status');
        $p = ($page - 1) * $count;
        $where = [];
        if ($name) {
            $where[] = ['name','like','%'.$name.'%'];
        }
        if ($color) {
            $where['color'] = $color;
        }
        if ($level) {
            $where['level'] =$level;
        }
        if (strlen($introduction)) {
            if ($introduction) {//字段不为空的情况
                //'LENGTH(your_field_name) > 0'
                $where[] = ['introduction', "<>", ""];
            } else {//字段为空的情况
                $where[] = ['introduction', "=", ""];
            }
        }
        if (strlen($person_img)) {
            if ($person_img) {//字段不为空的情况
                $where[] = ['person_img', "<>", ""];
            } else {//字段为空的情况
                $where[] = ['person_img', "=", ""];
            }
        }
        if (strlen($intersection_incident)) {
            if ($intersection_incident) {//字段不为空的情况
                //'LENGTH(your_field_name) > 0'
                $where[] = ['intersection_incident', "<>", ""];
            } else {//字段为空的情况
                $where[] = ['intersection_incident', "=", ""];
            }
        }

        if ($order_status) {
            $order_arr = ["id" => $order_status];
        }else{
            $order_arr = ["id" => "desc"];
        }
        $res = Db::name('relationInfo')->where($where)->order($order_arr)->limit($p, $count)->select();
        $total = Db::name('relationInfo')->where($where)->count();
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $res, "total" => $total]);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function updateRelationInfo()
    {
        $id = input('id');
        $data = [
            "module" => input("module"),//模块
            "name" => input("name"),//姓名
            "color" => input("color"),//颜色
            "level" => input("level"),//重要级别
            "introduction" => input("introduction"),//人物简介
            "person_img" => input("person_img"),//人物图片
            "intersection_incident" => input("intersection_incident"),//和宋庆龄的交集事件
            "group_photo" => input("group_photo")//人物与宋庆龄合照
        ];
        Db::name('relationInfo')->where('id', $id)->update($data);
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '修改成功', 'data' => "0");
        $json = json_encode($insert_result);
        echo $json;
    }

    public function DeleteRelationInfo()
    {
        $id = input('id');
        Db::name('relationInfo')->where('id', $id)->delete();
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '删除成功', 'data' => "0");
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getColorGroup()
    {
        $res = Db::name('relationInfo')->group("color")->column("color");
        $total = Db::name('relationInfo')->group("color")->count();
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $res, "total" => $total]);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getStatisticsInfo()
    {
        //把没有统计的数据更新到统计总表中
        $relation_exist = Db::name("statisticsInfoAll")->where('date', date("Y-m-d", time()))->where("table_name", "relation")->count();
        $res = Db::name('statisticsInfo')->where('table_name', "relation")->where('used_status', 0)
            ->field('sum(times) as sum_times, sum(time) as sum_time')->select();
        $sum_times = $res[0]['sum_times'];
        $sum_time = $res[0]['sum_time'];
        if ($sum_times) {
            if ($relation_exist) {
                Db::name('statisticsInfoAll')->where('date', date("Y-m-d", time()))->where("table_name", "relation")->update(['times' => Db::raw("times+$sum_times"), 'time' => Db::raw("time+$sum_time")]);
            } else {
                Db::name('statisticsInfoAll')->insert(['table_name' => 'relation', 'date' => date("Y-m-d", time()), 'times' => $res[0]['sum_times'], 'time' => $res[0]['sum_time']]);
            }
        }


        $life_exist = Db::name("statisticsInfoAll")->where('date', date("Y-m-d", time()))->where("table_name", "life")->count();
        $res = Db::name('statisticsInfo')->where('table_name', "life")->where('used_status', 0)
            ->field('sum(times) as sum_times, sum(time) as sum_time')->select();
        Db::name('statisticsInfo')->where('used_status', 0)->update(["used_status" => 1]);
        $sum_times = $res[0]['sum_times'];
        $sum_time = $res[0]['sum_time'];
        if ($sum_times) {
            if ($life_exist) {
                Db::name('statisticsInfoAll')->where('date', date("Y-m-d", time()))->where("table_name", "life")->update(['times' => Db::raw("times+$sum_times"), 'time' => Db::raw("time+$sum_time")]);
            } else {
                Db::name('statisticsInfoAll')->insert(['table_name' => 'life', 'date' => date("Y-m-d", time()), 'times' => $res[0]['sum_times'], 'time' => $res[0]['sum_time']]);
            }
        }

        //计算查询一级板块停留时间
        $res_first_level = Db::name('statisticsInfoAll')
            ->where("date", '>', date("Y-m-d", strtotime("-1 month", time())))
            ->field('sum(time) as value,table_name as name')
            ->group("table_name")
            ->select()->all();

        $all_time = 0;
        foreach ($res_first_level as $value) {
            $all_time += $value['value'];
        }
        foreach ($res_first_level as $key => $value) {
            $res_first_level[$key]['percent'] = round(($value['value'] / $all_time) * 100, 2);
        }


        //计算统计二级板块停留时间
        //探索生平——生平事件简介停留时间统计
        $res_second_level_life_content = Db::name('statisticsInfo')->alias('a')
            ->join("lifeDiscovery b", "b.id=a.table_id")
            ->where("a.create_time", '>', date("Y-m-d", strtotime("-1 month", time())) . "00:00:00")
            ->where('statistics_field', "content")
            ->field('sum(time) as sum_time,statistics_field,table_id,b.year')
            ->group("table_id")
            ->select()->all();
        //探索生平——宋庆龄与中国共产党史事节选停留时间统计
        $res_second_level_life_story_content = Db::name('statisticsInfo')->alias('a')
            ->join("lifeDiscovery b", "b.id=a.table_id")
            ->where("a.create_time", '>', date("Y-m-d", strtotime("-1 month", time())) . "00:00:00")
            ->where('statistics_field', "story_content")
            ->field('sum(time) as sum_time,statistics_field,table_id,b.story_content')
            ->group("table_id")
            ->select()->all();
        //关系图谱——人物简介停留时间统计
        $res_second_level_relation_introduction = Db::name('statisticsInfo')->alias('a')
            ->join("relationInfo b", "b.id=a.table_id")
            ->where("a.create_time", '>', date("Y-m-d", strtotime("-1 month", time())) . "00:00:00")
            ->where('statistics_field', "introduction")
            ->field('sum(time) as sum_time,statistics_field,table_id,b.introduction')
            ->group("table_id")
            ->select()->all();
        //关系图谱——和宋庆龄的交集事件停留时间统计
        $res_second_level_relation_intersection_incident = Db::name('statisticsInfo')->alias('a')
            ->join("relationInfo b", "b.id=a.table_id")
            ->where("a.create_time", '>', date("Y-m-d", strtotime("-1 month", time())) . "00:00:00")
            ->where('statistics_field', "intersection_incident")
            ->field('sum(time) as sum_time,statistics_field,table_id,b.intersection_incident')
            ->group("table_id")
            ->select()->all();
//        echo json_encode($res_second_level_life_content);

        $scope = input('scope');
        $where = [];
        if ($scope == "day") {
            $datetime = date("Y-m-d", strtotime("-1 day", time()));
            $where[] = ['create_time', 'like', "$datetime" . "%"];
        }
        if ($scope == "week") {
            $datetime_start = date("Y-m-d", strtotime("-7 days", time()));
            $datetime_end = date("Y-m-d", strtotime("-1 day", time()));
            $where[] = ['create_time', '>', $datetime_start . " 00:00:00"];
        }
        // echo json_encode($where);exit;
        $hot_word = Db::name('statisticsInfo')->where($where)->order("times", "desc")->limit(10)->select();
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => [
            'res_first_level'=>$res_first_level,
            'res_second_level_life_content'=>$res_second_level_life_content,
            'res_second_level_life_story_content'=>$res_second_level_life_story_content,
            'res_second_level_relation_introduction'=>$res_second_level_relation_introduction,
            'res_second_level_relation_intersection_incident'=>$res_second_level_relation_intersection_incident,
            'hot_word'=>$hot_word
        ]]);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function importExcelLife()
    {
        $file_path = input("file_path");
        $api = new Api($this->app);
        $data = $api->importExcel($file_path);
        $res = [];
        foreach ($data as $value) {
            $res[] = [
                'age' => $value['A'],
                'year' => $value['B'],
                'content' => $value['C'],
                'year_story' => $value['D'],
                'story_content' => $value['E'],
                'year_story_content' => $value['F']
            ];
        }
        Db::name('lifeDiscovery')->insertAll($res);
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => "保存成功", 'data' => []);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function importExcelRelation()
    {
        $file_path = input("file_path");
        $api = new Api($this->app);
        $data = $api->importExcel($file_path);
        $res = [];
        foreach ($data as $value) {
            $res[] = [
                'module' => $value['A'],
                'name' => $value['B'],
                'color' => $value['C'],
                'level' => $value['D'],
                'introduction' => $value['E'],
                'intersection_incident' => $value['F']
            ];
        }
        Db::name('relationInfo')->insertAll($res);
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => "保存成功", 'data' => []);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getMenu()
    {
        $insert_result = array('result' => "success", 'error' => "0", 'msg' => "保存成功", 'data' => []);
        $json = json_encode($insert_result);
        echo $json;
    }
    public function login()
    {
        if (request()->isPost()) {
//            $user = new UserModel($this->app);
//            $data = input('post.');
//            $result = $user->login($data['username'], $data['password']);
//            if ($result) {
//                // 登录成功，跳转到首页或其他页面
//                echo redirect('index/index');
//            } else {
//                // 登录失败，显示错误信息
//                echo '登录失败';
//            }
        } else {
            // 显示登录表单
            echo view();
        }
    }
    public function getLifeInfo()
    {
        echo view("life");
    }
    public function slide()
    {
        echo view("slide");
    }

}
//
//<!---->
//<!--<html>-->
//<!--<div style="background-color:#eaeef0 "></div>-->
//<!--</html>-->
