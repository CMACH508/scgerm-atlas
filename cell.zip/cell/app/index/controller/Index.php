<?php

namespace app\index\controller;
header("Content-type: application/json");
header('Access-Control-Allow-Origin:*');
header("Access-Control-Allow-Methods: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Access-Token,Content-Length, Accept-Encoding, X-Requested-With, Origin");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Expose-Headers: *");
header('Access-Control-Allow-Methods: GET, POST, PUT,DELETE,OPTIONS,PATCH');

use think\facade\Db;
use app\BaseController;
use think\facade\Cache;

class Index extends BaseController
{
    public function test()
    {
        echo 1234412341241244;
    }
    public function index()
    {
        echo 1234;
    }

    public function getGenesInfo()
    {
        $gene = input('gene');
        $gene_names = input('gene_names');
        $gene_seqence = input('gene_seqence');
        $page = input('page');
        $count = input('count');
        $p = ($page - 1) * $count;
        $where = [];
        if ($gene) {
            $where['gene'] = $gene;
        }
        if ($gene_names) {
            $where['gene_names'] = $gene_names;
        }
        if ($gene_seqence) {
            $where['gene_seqence'] = $gene_seqence;
        }
        $res = Db::name("genesInfo")->where($where)->select();
        $total = Db::name("genesInfo")->where($where)->count();
        if ($total!=1){
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => [], "total" => 0]);
        }else{
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $res, "total" => $total]);
        }

        $json = json_encode($insert_result);
        echo $json;
    }

    public function getGenesTargetInfo()
    {
        $tf = input('tf');
        $cor = input('cor');
        $pvalue = input('pvalue');
        $fdr = input("FDR");
        $page = input('page');
        $count = input('count');
        $p = ($page - 1) * $count;
        $where = [];
        $where_str = "";
        if ($tf) {
            $where['tf'] = $tf;
            if($cor =="true"){
                if($pvalue){
                    $where_str = "cor > $pvalue";
                }else{
                    $where_str = "cor < 0";
                }
            }elseif($cor == "false"){
                if($pvalue){
                    $where_str = "cor < $pvalue";
                }else{
                    $where_str = "cor > 0";
                }
            }else{
                $where_str = "";
            }
            if($fdr){//'FDR < 0.5 OR value = ?', ['a']
                $where_str.= " AND( fdr < '$fdr' OR fdr = '<0.001')";
    
            }
    //        "cor > $pvalue AND (fdr < '0.5' OR fdr = '<0.001')"
            $res = Db::name("genesTargetInfo")->field('*, ABS(`cor`) as `abs_cor`')->order('abs_cor','desc')->limit($p,$count)->where($where)->where($where_str)->select();
            $total = Db::name("genesTargetInfo")->where($where)->where($where_str)->count();
                $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $res, "total" => $total]);
        }else{
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => [], "total" => $total]);
        }
        
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getSearchName()
    {
        $gene = input('gene');
        $gene_name = input('gene_name');
        $gene_seqence = input('gene_seqence');

        $where = [];
        $column = "";
        if ($gene) {
            $where[] = ['gene','like','%'.$gene.'%'];
            $column = 'gene';
        }
        if ($gene_name) {
            $where[] = ['gene_names','like','%'.$gene_name.'%'];
            $column = 'gene_names';
        }
        if ($gene_seqence) {
            $where[] = ['gene_seqence','like','%'.$gene_seqence.'%'];
            $column = 'gene_seqence';
        }
        $res = Db::name("genesInfo")->where($where)->column($column);
        $total = Db::name("genesInfo")->where($where)->count();
//        $res = Db::name("genesInfo")->where($where)->select();
//        echo json_encode($where);exit;
        $result = [];
        if($total<200){

            foreach($res as $value){
                $result[] =['value'=>$value,'label'=>$value] ;
            }
        }

        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $result, "total" => 0]);
        $json = json_encode($insert_result);
        echo $json;
    }



    public function getTfSelectGroup()
    {
        $tf = input('tf');
        $where = [];

        if ($tf) {
            $where[] = ['tf','like','%'.$tf.'%'];

        }
        $res = Db::name('genesTargetInfo')->where($where)->group("tf")->column("tf");
        $total = Db::name('genesTargetInfo')->where($where)->group("tf")->count();
        $result = [];
        if($total<200){

            foreach($res as $value){
                $result[] =['value'=>$value,'label'=>$value] ;
            }
        }

        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $result, "total" => 0]);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getTargetSelectGroup()
    {
        $target = input('target');
        $where = [];

        if ($target) {
            $where[] = ['target','like','%'.$target.'%'];

        }
        $res = Db::name('genesTargetInfo')->where($where)->group("target")->column("target");
        $total = Db::name('genesTargetInfo')->where($where)->group("target")->count();
        $result = [];
        if($total<200){

            foreach($res as $value){
                $result[] =['value'=>$value,'label'=>$value] ;
            }
        }

        $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" => $result, "total" => 0]);
        $json = json_encode($insert_result);
        echo $json;
    }

    public function getComparePic()
    {
        $pic1=input('pic1');
        $pic2=input('pic2');
        
        $pic_url = Db::name("comparePicInfo")->where("pic1",$pic1)->where("pic2",$pic2)->value("pic_url");
        if($pic_url){
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" =>$pic_url , "total" => 0]);
        }else{
            $output = $pic1."_".$pic2;
            exec("/data/miniconda/envs/degradome/bin/python3 /data/c-elegans/website/public/target/right/corre.py /data/c-elegans/website/public/target/right/umap_color.txt $pic1 $pic2 /data/c-elegans/website/public/target/right/".$output,$file,$code);
        if ($code ==0){
            $data = [
              "pic1"=>$pic1,
              "pic2"=>$pic2,
              "pic_url"=>$output  
            ];
            Db::name("comparePicInfo")->insert($data);
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" =>$output , "total" => 0]);
           
        }else{
            $insert_result = array('result' => "false", 'error' => "-1", 'msg' => '获取失败', 'data' => ["result" =>"" , "total" => 0]);
        }
       
        }
        $json = json_encode($insert_result);
        echo $json;
    }

    public function get3DMap()
    {
        $gene=input('gene');
        
        $map_url = Db::name("3dMapInfo")->where("gene",$gene)->value("map_url");
        if($map_url){
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" =>$map_url , "total" => 0]);
        }else{
            $output = $gene.".html";
            exec("/data/miniconda/bin/python3 /data/c-elegans/website/public/target/right/umap3d.py /data/c-elegans/website/public/target/right/umap_color.txt $gene /data/c-elegans/website/public/target/right/".$output,$file,$code);
        if ($code ==0){
            $data = [
              "gene"=>$gene,
              "map_url"=>$output  
            ];
            Db::name("3dMapInfo")->insert($data);
            $insert_result = array('result' => "success", 'error' => "0", 'msg' => '获取成功', 'data' => ["result" =>$output , "total" => 0]);
           
        }else{
            $insert_result = array('result' => "false", 'error' => "-1", 'msg' => '获取失败', 'data' => ["result" =>"" , "total" => 0]);
        }
       
        }
        $json = json_encode($insert_result);
        echo $json;
    }
}