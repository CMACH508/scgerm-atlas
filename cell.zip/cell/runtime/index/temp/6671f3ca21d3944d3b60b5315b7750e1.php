<?php /*a:1:{s:60:"D:\xampp\htdocs\songqingling\app\index\view\admin\login.html";i:1710729367;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form method="post" action="<?php echo url('user/login'); ?>">
    用户名：<input type="text" name="username" />
    密码：<input type="password" name="password" />
    <button type="submit">登录</button>
</form>
</body>
</html>