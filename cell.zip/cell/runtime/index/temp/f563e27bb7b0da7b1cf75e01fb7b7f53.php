<?php /*a:2:{s:59:"D:\xampp\htdocs\songqingling\app\index\view\admin\life.html";i:1710733604;s:60:"D:\xampp\htdocs\songqingling\app\index\view\admin\slide.html";i:1710733732;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <script src="../../static/js/vue.js"></script>
  <script src="../../static/js/element_js.js"></script>
  <link rel="stylesheet" type="text/css" href="../../static/css/element_index.css">

  <meta charset="UTF-8">
  <title>test</title>
</head>
<body style="margin: 0px;overflow: hidden;">
<header>
    <!-- 引入样式 -->
    <link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css">
    <!-- 引入组件库 -->
    <script src="https://unpkg.com/element-ui/lib/index.js"></script>

</header>

<body>
<el-row class="tac">
    <el-col :span="12">
        <h5>默认颜色</h5>
        <el-menu
                default-active="2"
                class="el-menu-vertical-demo"
                @open="handleOpen"
                @close="handleClose">
            <el-submenu index="1">
                <template slot="title">
                    <i class="el-icon-location"></i>
                    <span>导航一</span>
                </template>
                <el-menu-item-group>
                    <template slot="title">分组一</template>
                    <el-menu-item index="1-1">选项1</el-menu-item>
                    <el-menu-item index="1-2">选项2</el-menu-item>
                </el-menu-item-group>
                <el-menu-item-group title="分组2">
                    <el-menu-item index="1-3">选项3</el-menu-item>
                </el-menu-item-group>
                <el-submenu index="1-4">
                    <template slot="title">选项4</template>
                    <el-menu-item index="1-4-1">选项1</el-menu-item>
                </el-submenu>
            </el-submenu>
            <el-menu-item index="2">
                <i class="el-icon-menu"></i>
                <span slot="title">导航二</span>
            </el-menu-item>
            <el-menu-item index="3" disabled>
                <i class="el-icon-document"></i>
                <span slot="title">导航三</span>
            </el-menu-item>
            <el-menu-item index="4">
                <i class="el-icon-setting"></i>
                <span slot="title">导航四</span>
            </el-menu-item>
        </el-menu>
    </el-col>
    <el-col :span="12">
        <h5>自定义颜色</h5>
        <el-menu
                default-active="2"
                class="el-menu-vertical-demo"
                @open="handleOpen"
                @close="handleClose"
                background-color="#545c64"
                text-color="#fff"
                active-text-color="#ffd04b">
            <el-submenu index="1">
                <template slot="title">
                    <i class="el-icon-location"></i>
                    <span>导航一</span>
                </template>
                <el-menu-item-group>
                    <template slot="title">分组一</template>
                    <el-menu-item index="1-1">选项1</el-menu-item>
                    <el-menu-item index="1-2">选项2</el-menu-item>
                </el-menu-item-group>
                <el-menu-item-group title="分组2">
                    <el-menu-item index="1-3">选项3</el-menu-item>
                </el-menu-item-group>
                <el-submenu index="1-4">
                    <template slot="title">选项4</template>
                    <el-menu-item index="1-4-1">选项1</el-menu-item>
                </el-submenu>
            </el-submenu>
            <el-menu-item index="2">
                <i class="el-icon-menu"></i>
                <span slot="title">导航二</span>
            </el-menu-item>
            <el-menu-item index="3" disabled>
                <i class="el-icon-document"></i>
                <span slot="title">导航三</span>
            </el-menu-item>
            <el-menu-item index="4">
                <i class="el-icon-setting"></i>
                <span slot="title">导航四</span>
            </el-menu-item>
        </el-menu>
    </el-col>
</el-row>
</body>
<script>
    export default {
        methods: {
            handleOpen(key, keyPath) {
                console.log(key, keyPath);
            },
            handleClose(key, keyPath) {
                console.log(key, keyPath);
            }
        }
    }
</script>
<div class="row">
  <div style="margin-left: 5%;width: 90%">
    <div class="search">
      <div id="tabs">
        <div style="height: 60px"></div>
        <div id="form">
          <el-form ref="form" :model="form">
            <template>
              <el-select class="select" v-model="form.gender" clearable placeholder="请选择性别">
                <el-option
                        v-for="item in gender"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select class="select" v-model="form.age" clearable placeholder="请选择年龄">
                <el-option
                        v-for="item in age"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select class="select" v-model="form.hypertension" clearable placeholder="是否有高血压">
                <el-option
                        v-for="item in hypertension"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select class="select" v-model="form.diabetes" clearable placeholder="是否有糖尿病">
                <el-option
                        v-for="item in diabetes"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select class="select" v-model="form.family_history_1" clearable placeholder="是否有家族病史">
                <el-option
                        v-for="item in family_history_1"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select class="select" v-model="form.family_history_2" clearable placeholder="是否有家族病史">
                <el-option
                        v-for="item in family_history_2"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select class="select" v-model="form.smoking_history" clearable placeholder="是否有吸烟史">
                <el-option
                        v-for="item in smoking_history"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select class="select" v-model="form.drinking_history" clearable placeholder="是否有饮酒史">
                <el-option
                        v-for="item in drinking_history"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
              </el-select>
            </template>
            <el-button type="primary" @click="onSubmit">
              Search
            </el-button>
            <!--<div style="font-size: small">Exampless:REG18</div>-->
            <div style="height: 90px"></div>

          </el-form>
        </div>
      </div>
    </div>
    <div>

    </div>
    <div class="row">
      <div class="column left">
        <p style="font-size: x-large;color: #a5a6a5">Select Columns to show</p>
        <p style="font-size: large;">Homo sapiens</p>
        <div style="margin-left: 3%" id="checkbox">
          <template>
            <el-checkbox-group v-model="checkList">
              <div class="checkbox">
                <el-checkbox label="编号"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="number"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="性别"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="年龄"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="高血压"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="糖尿病"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="家族史1"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="家族史2"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="吸烟史"></el-checkbox>
              </div>
              <div class="checkbox">
                <el-checkbox label="饮酒史"></el-checkbox>
              </div>
            </el-checkbox-group>
          </template>
        </div>
      </div>
      <div class="column right">
        <div id="table" style="">
          <template>
            <el-table
                    :data="tableData"
                    border
                    :header-cell-style="{textAlign: 'center'}"
                    :cell-style="{ textAlign: 'center' }"
                    style="width: 100%">
              <el-table-column prop="code" label="编号" width="150"></el-table-column>
              <el-table-column prop="number" label="number"></el-table-column>
              <el-table-column prop="gender" label="性别"></el-table-column>
              <el-table-column prop="age" label="年龄"></el-table-column>
              <el-table-column prop="hypertension" label="高血压"></el-table-column>
              <el-table-column prop="diabetes" label="糖尿病"></el-table-column>
              <el-table-column prop="family_history_1" label="家族史1"></el-table-column>
              <el-table-column prop="family_history_2" label="家族史2"></el-table-column>
              <el-table-column prop="smoking_history" label="吸烟史"></el-table-column>
              <el-table-column prop="drinking_history" label="饮酒史"></el-table-column>
            </el-table>
            <div id="page">
              <div class="block" style="margin-top: 15px">
                <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page.sync="currentPage"

                        layout="total, prev, pager, next, jumper"
                       >
                </el-pagination>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
  * {
    box-sizing: border-box;
  }

  .select {
    width: 10%;
    margin-right: 14px
  }

  .column {
    float: left;
    padding: 10px;
    height: 600px;

  }

  .checkbox {
    margin-top: 10px;
    font-size: x-large;
  }

  /* 左右两侧宽度 */
  .column.left {
    margin-top: -2%;
    width: 20%;
  / / background-color: #3a8ee6;
  }

  .column.right {
    width: 80%;

  / / background-color: #8558e6;
  }

  /* 中间区域宽度 */
  .column.middle {
    width: 25%;
  }

  /* 列后面清除浮动 */
  .row:after {
    content: "";
    display: table;
    clear: both;
  }

  @import url("//unpkg.com/element-ui@2.15.5/lib/theme-chalk/index.css");
  .row {
    color: black;
  / / background: linear-gradient(to left, #70b6cf, #a1edff, #70b6cf) bottom center no-repeat;
    background: #ffffff;

    height: 43rem;

  }

  .search {
    /*border: 1px solid #000;*/
    /*border-radius: 5px;*/
    /*height: 200px;*/
  }

  .el-button + .el-button {
    margin-left: 2%;
  }

  /* 创建两列 */
  /* Left column */
  .leftcolumn {
    float: left;
    width: 50%;

  }

  /* 右侧栏 */
  .rightcolumn {
    float: left;
    width: 50%;
    background-color: #f1f1f1;
  }

  /* 列后面清除浮动 */
  .row:after {
    content: "";
    display: table;
    clear: both;
  }

  .el-row {
    margin-bottom: 20px;

  &
  :last-child {
    margin-bottom: 0;
  }

  }
  .el-col {
    border-radius: 4px;
  }

  .bg-purple-dark {
    background: #99a9bf;
  }

  .bg-purple {
    background: #d3dce6;
  }

  .bg-purple-light {
    background: #e5e9f2;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 100px;
    text-align: center;
  }

  .row-bg {
    padding: 10px 0;
    /*background-color: #f9fafc;*/
  }

</style>

<script type="module">

  var Main = {
    data() {
      return {
        activeIndex: '3',
        index: ''
      };
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }

  var Ctor = Vue.extend(Main)
  new Ctor().$mount('#app3')

  var Main2 = {
    data() {
      return {
        activeName: 'first',
        input: '',
        form: {

        },
        gender: [{
          value: '1',
          label: '男'
        }, {
          value: '2',
          label: '女'
        }],
        age: [{
          value: '0-50',
          label: '50岁以下'
        }, {
          value: '50-60',
          label: '50-60岁'
        }, {
          value: '60-70',
          label: '50-60岁'
        }, {
          value: '70-80',
          label: '50-60岁'
        }, {
          value: '80-110',
          label: '80岁以上'
        }],
        hypertension: [{
          value: '0',
          label: '无'
        }, {
          value: '1',
          label: '有'
        }],
        diabetes: [{
          value: '0',
          label: '无'
        }, {
          value: '1',
          label: '有'
        }],
        family_history_1: [{
          value: '0',
          label: '无'
        }, {
          value: '1',
          label: '有'
        }],
        family_history_2: [{
          value: '0',
          label: '无'
        }, {
          value: '2',
          label: '胃癌'
        }, {
          value: '3',
          label: '其他癌'
        }],
        smoking_history: [{
          value: '0',
          label: '无'
        }, {
          value: '1',
          label: '有'
        }],
        drinking_history: [{
          value: '0',
          label: '无'
        }, {
          value: '1',
          label: '有'
        }],

      };
    },
    methods: {
      handleClick(tab, event) {
        console.log(tab, event);
      },
      onSubmit() {
        console.log('submit!');
        var str = "<?php echo url('basicInformation'); ?>?" + "gender=" + this.form.gender + "&age=" + this.form.age + "&hypertension=" + this.form.hypertension + "&diabetes="
                + this.form.diabetes + "&family_history_1=" + this.form.family_history_1 + "&family_history_2=" + this.form.family_history_2 + "&smoking_history=" + this.form.smoking_history + "&drinking_history=" + this.form.drinking_history;
        window.location.href = str;
        console.log(this.form.name);
      }
    }
  };
  var Ctor2 = Vue.extend(Main2)
  new Ctor2().$mount('#tabs')


  var Main3 = {
    methods: {
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        var str = "<?php echo url('basicInformation'); ?>?" + "page=" + val + "&gender=" + obj.gender;
        window.location.href = str;
        console.log(`当前页: ${val}`);
      }
    },
    data() {
      return {



      }
    }
  }

  var Ctor3 = Vue.extend(Main3)
  new Ctor3().$mount('#table')


  var Main4 = {
    data() {
      return {
        checkList: ['编号', 'number', '性别', '年龄', '高血压', '糖尿病', '家族史1', '家族史2', '吸烟史', '饮酒史']
      };
    }
  };
  var Ctor4 = Vue.extend(Main4)
  new Ctor4().$mount('#checkbox')


</script>
</body>
</html>